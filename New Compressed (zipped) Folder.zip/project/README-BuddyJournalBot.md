# Buddy JournalBot 🤖✨

A friendly, AI-powered journaling assistant built with React that helps users explore their thoughts, celebrate their wins, and build a meaningful daily writing practice.

## ✨ Features

- **Conversational AI Interface**: Chat with Buddy, your empathetic journaling companion
- **Smart Response Generation**: Powered by Google Gemini API with intelligent fallback responses
- **Journaling Prompts**: 15+ thoughtful prompts to inspire reflection and self-discovery
- **Local Storage**: All journal entries stored locally for privacy and security
- **Responsive Design**: Beautiful, mobile-friendly interface built with Tailwind CSS
- **Auto-tagging**: Automatically identifies and tags common journaling themes
- **Print Support**: Export your journal entries for offline reading
- **Real-time Chat**: Smooth conversation flow with typing indicators

## 🚀 Quick Start

### 1. Installation

```bash
npm install lucide-react
```

### 2. Environment Setup

Create a `.env` file in your project root:

```env
VITE_GEMINI_API_KEY=your_gemini_api_key_here
```

**Note**: If you don't have a Google Gemini API key, the component will work with intelligent fallback responses. In Vite, environment variables must start with `VITE_` to be exposed to the browser.

### 3. Basic Usage

```tsx
import React from 'react';
import BuddyJournalBot from './components/BuddyJournalBot';

function App() {
  return (
    <div className="App">
      <BuddyJournalBot />
    </div>
  );
}
```

### 4. Demo Page

For a complete showcase, use the demo component:

```tsx
import React from 'react';
import BuddyJournalBotDemo from './components/BuddyJournalBotDemo';

function App() {
  return (
    <div className="App">
      <BuddyJournalBotDemo />
    </div>
  );
}
```

## 🏗️ Component Architecture

### Core Components

- **BuddyJournalBot**: Main chat interface component
- **BuddyJournalBotDemo**: Complete demo page with features showcase

### Key Features

#### Chat System
- Real-time message exchange
- Typing indicators
- Auto-scroll to latest messages
- Timestamp tracking

#### AI Integration
- Google Gemini Pro integration
- Intelligent fallback responses
- Context-aware conversations
- Empathetic and encouraging tone

#### Journal Management
- Local storage for entries
- Automatic tagging system
- Entry history tracking
- Print functionality

#### User Experience
- Responsive design
- Keyboard shortcuts (Enter to send)
- Focus management
- Smooth animations

## 🔧 Configuration

### Google Gemini API Setup

1. Get your API key from [Google AI Studio](https://makersuite.google.com/app/apikey)
2. Add to your `.env` file:
   ```env
   VITE_GEMINI_API_KEY=your-gemini-api-key-here
   ```
3. The component will automatically use the API when available

### Customization Options

#### Modify Journaling Prompts

```tsx
// In BuddyJournalBot.tsx, update JOURNALING_PROMPTS array
const JOURNALING_PROMPTS = [
  "Your custom prompt here",
  "Another inspiring question",
  // ... more prompts
];
```

#### Adjust Bot Personality

```tsx
// Modify the system prompt in generateBotResponse function
content: `You are Buddy, a friendly, empathetic journaling assistant. Your role is to:
- Provide warm, encouraging responses
- Ask thoughtful follow-up questions
- Offer positive reinforcement
- Keep responses conversational and under 100 words`
```

#### Change Styling

The component uses Tailwind CSS classes. You can customize:

```tsx
// Update color scheme
className="bg-gradient-to-r from-purple-500 to-pink-600" // Change header colors

// Update chat bubble colors
className="bg-purple-500 text-white" // Change user message colors
```

## 📱 Responsive Design

The component is fully responsive and works on:
- Desktop (1024px+)
- Tablet (768px - 1023px)
- Mobile (320px - 767px)

## 🔒 Privacy & Security

- **Local Storage**: All journal entries stored in browser localStorage
- **No External Sharing**: Entries never leave your device
- **API Security**: OpenAI API calls use secure HTTPS
- **Data Protection**: No personal data collected or stored

## 🎨 Styling & Theming

### Color Scheme
- **Primary**: Teal (#14b8a6)
- **Secondary**: Blue (#0ea5e9)
- **Accent**: Purple (#8b5cf6)
- **Background**: Gradient from teal-50 to blue-50

### Typography
- **Headers**: Bold, large text for hierarchy
- **Body**: Readable, medium-weight text
- **Captions**: Small, muted text for metadata

### Components
- **Cards**: Rounded corners with subtle shadows
- **Buttons**: Hover effects and smooth transitions
- **Inputs**: Focus states with ring indicators

## 🧪 Testing

### Manual Testing Checklist

- [ ] Chat interface loads correctly
- [ ] User messages appear in chat
- [ ] Bot responds appropriately
- [ ] Journal entries are saved
- [ ] Prompts are clickable
- [ ] Print functionality works
- [ ] Responsive design on different screen sizes
- [ ] Keyboard shortcuts function properly

### Automated Testing

```bash
# Run tests (if you have testing setup)
npm test

# Test specific component
npm test BuddyJournalBot
```

## 🚀 Performance

- **Lazy Loading**: Components load only when needed
- **Optimized Re-renders**: Efficient state management
- **Minimal Dependencies**: Only essential packages included
- **Bundle Size**: Lightweight component (~15KB gzipped)

## 🔮 Future Enhancements

- [ ] Cloud sync with user accounts
- [ ] Advanced analytics and insights
- [ ] Mood tracking integration
- [ ] Export to various formats (PDF, Word)
- [ ] Collaborative journaling
- [ ] Voice-to-text input
- [ ] Custom themes and personalization

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## ⚠️ Important Notes

### Mental Health Disclaimer

Buddy JournalBot is designed to support healthy journaling practices and is **NOT** a substitute for professional mental health care. If you're experiencing a mental health crisis, please:

- Contact a mental health professional
- Call your local crisis hotline
- Visit the nearest emergency room
- Call 988 (National Suicide Prevention Lifeline in the US)

### API Usage

- Google Gemini API calls incur costs based on usage
- Monitor your API usage in the Google AI Studio dashboard
- Consider implementing rate limiting for production use
- The fallback system ensures the component works without API access

## 🆘 Troubleshooting

### Common Issues

#### Google Gemini API Not Working
- Check your API key in `.env` file
- Verify API key has sufficient credits
- Check network connectivity
- Component will fall back to local responses

#### Styling Issues
- Ensure Tailwind CSS is properly configured
- Check for CSS conflicts in your project
- Verify all required CSS classes are available

#### Local Storage Issues
- Check browser console for errors
- Ensure localStorage is enabled
- Clear browser cache if needed

### Getting Help

- Check the browser console for error messages
- Verify all dependencies are installed
- Ensure environment variables are set correctly
- Test with the demo component first

## 📚 Additional Resources

- [React Documentation](https://reactjs.org/)
- [Tailwind CSS](https://tailwindcss.com/)
- [Google Gemini API Documentation](https://ai.google.dev/docs/)
- [Journaling Benefits Research](https://www.health.harvard.edu/mental-health/the-healing-power-of-journaling)

---

Built with ❤️ for mental wellness and self-reflection
